import { Module } from "@nestjs/common";
import { AuthController } from "./auth.controller";
import { AuthService } from "./auth.service";
import { UserService } from "src/modules/user/interface/user.service";
import { JwtModule } from "@nestjs/jwt";
import { UtilService } from "src/common/services/util.service";

@Module({
    controllers: [AuthController],
    providers: [AuthService,UserService,UtilService],
    imports:[JwtModule.register({
      secret: 'tu_secreto_super_seguro', // En producción usa variables de entorno
      signOptions: { expiresIn: '60s' }, // 60 segundos de expiración
    }),]
})
export class AuthModule {
    
}

