import { Body, Controller, Get, HttpCode, HttpStatus, Post } from "@nestjs/common";
import { AuthService } from "./auth.service";
import { LoginDto } from "../dto/login.dto";

@Controller('api/auth')
export class AuthController{

    constructor(private authSvc: AuthService){}

    //Post /auth/register -201 Created
    // @Post("/login")
    // @HttpCode(HttpStatus.OK)
    // public login(@Body() loginDto:LoginDto):string{
    //     const {username,password}=loginDto;

    //     //TODO: verificar el usuario y contraseña


    //     //TODO: Obtener la informacion del usuario payload

    //     //TODO: Generar el token JWT

    //     //TODO: Devolver el token jwt encriptado

    //         return this.authSvc.login();
    //     }
    @Post("/login")
    @HttpCode(HttpStatus.OK)
    async login(@Body() loginDto: LoginDto): Promise<{ access_token: string }> {
        const { username, password } = loginDto;
        // Llamar al servicio de autenticación
        return this.authSvc.login(username, password);
    }
    
    

    @Get("/me")
    public getProfile(){

    }

    @Post("/refresh")
    public refreshToken(){

    }
    @Post("/logout")
    public logout(){

    }
}