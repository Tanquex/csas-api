import { Injectable, UnauthorizedException } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { UtilService } from "src/common/services/util.service";
import { UserService } from "src/modules/user/interface/user.service";

@Injectable()
export class AuthService{
    constructor(private readonly userService: UserService,
        private readonly utilService:UtilService,
        private readonly jwtService: JwtService
    ){}

    async signIn(id: number, pass: string): Promise<any> {
    const user = await this.userService.getUserById(id);
    if (user?.password !== pass) {
      throw new UnauthorizedException();
    }
    const { password, ...result } = user;
    // TODO: Generate a JWT and return it here
    // instead of the user object
    return result;
  }

    async login(username: string, password: string): Promise<{ access_token: string }> {
    // 1. Buscar usuario por username (incluye password)
    const user = await this.userService.getUserByUsername(username);
    if (!user) {
      throw new UnauthorizedException('Credenciales inválidas');
    }

    // 2. Verificar que el usuario tenga contraseña (por si acaso)
    if (!user.password) {
      // Esto no debería ocurrir si la BD tiene contraseña siempre, pero TypeScript lo exige
      throw new UnauthorizedException('Credenciales inválidas');
    }

    // 3. Comparar contraseñas usando bcrypt
    const passwordValid = await this.utilService.checkPassword(password, user.password);
    if (!passwordValid) {
      throw new UnauthorizedException('Credenciales inválidas');
    }

    // 4. Generar payload y token
    const payload = { sub: user.id, username: user.username };
    const access_token = this.jwtService.sign(payload);

    return { access_token };
  }

}