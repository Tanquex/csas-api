import { IsDate, IsNotEmpty, IsString, MaxLength, MinLength } from "class-validator";

export class CreateUserDto{
    @IsString()
    @IsNotEmpty()
    @MinLength(3)
    @MaxLength(200)
    name: string; 

    @IsString()
    @IsNotEmpty()
    @MinLength(3)
    @MaxLength(300)
    lastname: string; 

    @IsString()
    @IsNotEmpty()
    @MinLength(3)
    @MaxLength(100)
    username: string;
    
    @IsString()
    @IsNotEmpty()
    @MinLength(3)
    @MaxLength(100)
    password: string; 

    @IsDate()
    
    created_at: Date; 
}